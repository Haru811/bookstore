﻿namespace HeThongSach
{
    partial class BookAgentInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            returnToMenuToolStripMenuItem = new ToolStripMenuItem();
            agent = new TextBox();
            add = new TextBox();
            phone = new TextBox();
            paid = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            dataGridView1 = new DataGridView();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            label5 = new Label();
            id = new TextBox();
            menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.BackColor = SystemColors.ButtonFace;
            menuStrip1.Items.AddRange(new ToolStripItem[] { returnToMenuToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(898, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // returnToMenuToolStripMenuItem
            // 
            returnToMenuToolStripMenuItem.Name = "returnToMenuToolStripMenuItem";
            returnToMenuToolStripMenuItem.Size = new Size(102, 20);
            returnToMenuToolStripMenuItem.Text = "Return to Menu";
            returnToMenuToolStripMenuItem.Click += returnToMenuToolStripMenuItem_Click;
            // 
            // agent
            // 
            agent.Location = new Point(168, 70);
            agent.Name = "agent";
            agent.Size = new Size(221, 23);
            agent.TabIndex = 1;
            agent.TextChanged += agent_TextChanged;
            // 
            // add
            // 
            add.Location = new Point(424, 70);
            add.Name = "add";
            add.Size = new Size(186, 23);
            add.TabIndex = 2;
            // 
            // phone
            // 
            phone.Location = new Point(168, 121);
            phone.Name = "phone";
            phone.Size = new Size(100, 23);
            phone.TabIndex = 3;
            // 
            // paid
            // 
            paid.Location = new Point(478, 121);
            paid.Name = "paid";
            paid.Size = new Size(132, 23);
            paid.TabIndex = 4;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(168, 52);
            label1.Name = "label1";
            label1.Size = new Size(74, 15);
            label1.TabIndex = 7;
            label1.Text = "Agent Name";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(424, 52);
            label2.Name = "label2";
            label2.Size = new Size(49, 15);
            label2.TabIndex = 8;
            label2.Text = "Address";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(168, 103);
            label3.Name = "label3";
            label3.Size = new Size(88, 15);
            label3.TabIndex = 9;
            label3.Text = "Phone Number";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(478, 103);
            label4.Name = "label4";
            label4.Size = new Size(30, 15);
            label4.TabIndex = 10;
            label4.Text = "Paid";
            // 
            // dataGridView1
            // 
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(72, 184);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(645, 370);
            dataGridView1.TabIndex = 11;
            dataGridView1.CellClick += dataGridView1_CellClick;
            // 
            // button3
            // 
            button3.Location = new Point(765, 384);
            button3.Name = "button3";
            button3.Size = new Size(75, 23);
            button3.TabIndex = 26;
            button3.Text = "Update";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.Location = new Point(765, 340);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 25;
            button2.Text = "Delete";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.Location = new Point(765, 295);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 24;
            button1.Text = "Add";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(315, 103);
            label5.Name = "label5";
            label5.Size = new Size(53, 15);
            label5.TabIndex = 28;
            label5.Text = "Agent ID";
            // 
            // id
            // 
            id.Location = new Point(315, 121);
            id.Name = "id";
            id.Size = new Size(122, 23);
            id.TabIndex = 29;
            // 
            // BookAgentInfo
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Info;
            ClientSize = new Size(898, 639);
            Controls.Add(id);
            Controls.Add(label5);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(dataGridView1);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(paid);
            Controls.Add(phone);
            Controls.Add(add);
            Controls.Add(agent);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "BookAgentInfo";
            Text = "BookAgentInfo";
            Load += BookAgentInfo_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem returnToMenuToolStripMenuItem;
        private TextBox agent;
        private TextBox add;
        private TextBox phone;
        private TextBox paid;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private DataGridView dataGridView1;
        private Button button3;
        private Button button2;
        private Button button1;
        private Label label5;
        private TextBox id;
    }
}