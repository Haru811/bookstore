﻿namespace HeThongSach
{
    partial class PublishingHouseInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            name = new TextBox();
            add = new TextBox();
            phone = new TextBox();
            cac = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            dataGridView1 = new DataGridView();
            menuStrip1 = new MenuStrip();
            returnToMenuToolStripMenuItem = new ToolStripMenuItem();
            pay = new TextBox();
            id = new TextBox();
            label5 = new Label();
            label6 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // name
            // 
            name.Location = new Point(107, 76);
            name.Name = "name";
            name.Size = new Size(243, 23);
            name.TabIndex = 0;
            // 
            // add
            // 
            add.Location = new Point(369, 76);
            add.Name = "add";
            add.Size = new Size(150, 23);
            add.TabIndex = 1;
            // 
            // phone
            // 
            phone.Location = new Point(107, 134);
            phone.Name = "phone";
            phone.Size = new Size(175, 23);
            phone.TabIndex = 2;
            // 
            // cac
            // 
            cac.Location = new Point(322, 134);
            cac.Name = "cac";
            cac.Size = new Size(150, 23);
            cac.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(107, 58);
            label1.Name = "label1";
            label1.Size = new Size(135, 15);
            label1.TabIndex = 4;
            label1.Text = "Publishing House Name";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(369, 58);
            label2.Name = "label2";
            label2.Size = new Size(49, 15);
            label2.TabIndex = 5;
            label2.Text = "Address";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(107, 116);
            label3.Name = "label3";
            label3.Size = new Size(88, 15);
            label3.TabIndex = 6;
            label3.Text = "Phone Number";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(322, 116);
            label4.Name = "label4";
            label4.Size = new Size(79, 15);
            label4.TabIndex = 7;
            label4.Text = "Card Number";
            // 
            // button3
            // 
            button3.Location = new Point(789, 391);
            button3.Name = "button3";
            button3.Size = new Size(75, 23);
            button3.TabIndex = 27;
            button3.Text = "Update";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.Location = new Point(789, 347);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 26;
            button2.Text = "Delete";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.Location = new Point(789, 302);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 25;
            button1.Text = "Add";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(74, 193);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(675, 390);
            dataGridView1.TabIndex = 24;
            dataGridView1.CellClick += dataGridView1_CellClick;
            // 
            // menuStrip1
            // 
            menuStrip1.BackColor = SystemColors.ButtonFace;
            menuStrip1.Items.AddRange(new ToolStripItem[] { returnToMenuToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(907, 24);
            menuStrip1.TabIndex = 29;
            menuStrip1.Text = "menuStrip1";
            // 
            // returnToMenuToolStripMenuItem
            // 
            returnToMenuToolStripMenuItem.Name = "returnToMenuToolStripMenuItem";
            returnToMenuToolStripMenuItem.Size = new Size(102, 20);
            returnToMenuToolStripMenuItem.Text = "Return to Menu";
            returnToMenuToolStripMenuItem.Click += returnToMenuToolStripMenuItem_Click;
            // 
            // pay
            // 
            pay.Location = new Point(510, 134);
            pay.Name = "pay";
            pay.Size = new Size(150, 23);
            pay.TabIndex = 30;
            // 
            // id
            // 
            id.Location = new Point(542, 76);
            id.Name = "id";
            id.Size = new Size(118, 23);
            id.TabIndex = 31;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(542, 58);
            label5.Name = "label5";
            label5.Size = new Size(114, 15);
            label5.TabIndex = 32;
            label5.Text = "Publishing House ID";
            label5.Click += label5_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(510, 116);
            label6.Name = "label6";
            label6.Size = new Size(54, 15);
            label6.TabIndex = 33;
            label6.Text = "Payment";
            // 
            // PublishingHouseInfo
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Info;
            ClientSize = new Size(907, 648);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(id);
            Controls.Add(pay);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(dataGridView1);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(cac);
            Controls.Add(phone);
            Controls.Add(add);
            Controls.Add(name);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "PublishingHouseInfo";
            Text = "PublishingHouseInfo";
            Load += PublishingHouseInfo_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox name;
        private TextBox add;
        private TextBox phone;
        private TextBox cac;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Button button3;
        private Button button2;
        private Button button1;
        private DataGridView dataGridView1;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem returnToMenuToolStripMenuItem;
        private TextBox pay;
        private TextBox id;
        private Label label5;
        private Label label6;
    }
}