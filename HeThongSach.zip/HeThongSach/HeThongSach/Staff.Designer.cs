﻿namespace HeThongSach
{
    partial class Staff
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            name = new TextBox();
            id = new TextBox();
            phone = new TextBox();
            salary = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            dataGridView1 = new DataGridView();
            menuStrip1 = new MenuStrip();
            returnToMenuToolStripMenuItem = new ToolStripMenuItem();
            update = new Button();
            delete = new Button();
            add = new Button();
            role = new ComboBox();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // name
            // 
            name.Location = new Point(149, 72);
            name.Name = "name";
            name.Size = new Size(277, 23);
            name.TabIndex = 0;
            name.TextChanged += textBox1_TextChanged;
            // 
            // id
            // 
            id.Location = new Point(476, 72);
            id.Name = "id";
            id.Size = new Size(200, 23);
            id.TabIndex = 1;
            // 
            // phone
            // 
            phone.Location = new Point(149, 144);
            phone.Name = "phone";
            phone.Size = new Size(133, 23);
            phone.TabIndex = 2;
            // 
            // salary
            // 
            salary.Location = new Point(335, 144);
            salary.Name = "salary";
            salary.Size = new Size(154, 23);
            salary.TabIndex = 4;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(149, 54);
            label1.Name = "label1";
            label1.Size = new Size(39, 15);
            label1.TabIndex = 5;
            label1.Text = "Name";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(476, 54);
            label2.Name = "label2";
            label2.Size = new Size(18, 15);
            label2.TabIndex = 6;
            label2.Text = "ID";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(149, 126);
            label3.Name = "label3";
            label3.Size = new Size(86, 15);
            label3.TabIndex = 7;
            label3.Text = "Phone number";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(335, 126);
            label4.Name = "label4";
            label4.Size = new Size(38, 15);
            label4.TabIndex = 8;
            label4.Text = "Salary";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(526, 126);
            label5.Name = "label5";
            label5.Size = new Size(30, 15);
            label5.TabIndex = 9;
            label5.Text = "Role";
            // 
            // dataGridView1
            // 
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(91, 206);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(645, 336);
            dataGridView1.TabIndex = 10;
            dataGridView1.CellClick += dataGridView1_CellClick;
            // 
            // menuStrip1
            // 
            menuStrip1.BackColor = SystemColors.ButtonFace;
            menuStrip1.Items.AddRange(new ToolStripItem[] { returnToMenuToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(905, 24);
            menuStrip1.TabIndex = 14;
            menuStrip1.Text = "menuStrip1";
            // 
            // returnToMenuToolStripMenuItem
            // 
            returnToMenuToolStripMenuItem.Name = "returnToMenuToolStripMenuItem";
            returnToMenuToolStripMenuItem.Size = new Size(102, 20);
            returnToMenuToolStripMenuItem.Text = "Return to Menu";
            returnToMenuToolStripMenuItem.Click += returnToMenuToolStripMenuItem_Click;
            // 
            // update
            // 
            update.Location = new Point(782, 384);
            update.Name = "update";
            update.Size = new Size(75, 23);
            update.TabIndex = 26;
            update.Text = "Update";
            update.UseVisualStyleBackColor = true;
            update.Click += update_Click;
            // 
            // delete
            // 
            delete.Location = new Point(782, 340);
            delete.Name = "delete";
            delete.Size = new Size(75, 23);
            delete.TabIndex = 25;
            delete.Text = "Delete";
            delete.UseVisualStyleBackColor = true;
            delete.Click += delete_Click;
            // 
            // add
            // 
            add.Location = new Point(782, 295);
            add.Name = "add";
            add.Size = new Size(75, 23);
            add.TabIndex = 24;
            add.Text = "Add";
            add.UseVisualStyleBackColor = true;
            add.Click += add_Click;
            // 
            // role
            // 
            role.FormattingEnabled = true;
            role.Items.AddRange(new object[] { "IMPORT", "EXPORT", "PUBLISHING", "STATISTIC" });
            role.Location = new Point(526, 146);
            role.Name = "role";
            role.Size = new Size(150, 23);
            role.TabIndex = 28;
            // 
            // Staff
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Info;
            ClientSize = new Size(905, 618);
            Controls.Add(role);
            Controls.Add(update);
            Controls.Add(delete);
            Controls.Add(add);
            Controls.Add(dataGridView1);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(salary);
            Controls.Add(phone);
            Controls.Add(id);
            Controls.Add(name);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Staff";
            Text = "Staff";
            Load += Staff_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox name;
        private TextBox id;
        private TextBox phone;
        private TextBox salary;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private DataGridView dataGridView1;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem returnToMenuToolStripMenuItem;
        private Button update;
        private Button delete;
        private Button add;
        private ComboBox role;
    }
}