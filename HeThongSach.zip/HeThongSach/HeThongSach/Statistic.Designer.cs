﻿namespace HeThongSach
{
    partial class Statistic
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            stocksToolStripMenuItem = new ToolStripMenuItem();
            thongCuteToolStripMenuItem = new ToolStripMenuItem();
            dataGridView1 = new DataGridView();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            label1 = new Label();
            menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.BackColor = SystemColors.ButtonFace;
            menuStrip1.Items.AddRange(new ToolStripItem[] { stocksToolStripMenuItem, thongCuteToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(932, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // stocksToolStripMenuItem
            // 
            stocksToolStripMenuItem.Name = "stocksToolStripMenuItem";
            stocksToolStripMenuItem.Size = new Size(91, 20);
            stocksToolStripMenuItem.Text = "Unsold Books";
            stocksToolStripMenuItem.Click += stocksToolStripMenuItem_Click;
            // 
            // thongCuteToolStripMenuItem
            // 
            thongCuteToolStripMenuItem.Name = "thongCuteToolStripMenuItem";
            thongCuteToolStripMenuItem.Size = new Size(120, 20);
            thongCuteToolStripMenuItem.Text = "StatisticFromAgent";
            thongCuteToolStripMenuItem.Click += thongCuteToolStripMenuItem_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(57, 129);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(722, 414);
            dataGridView1.TabIndex = 1;
            // 
            // button3
            // 
            button3.Location = new Point(819, 340);
            button3.Name = "button3";
            button3.Size = new Size(75, 23);
            button3.TabIndex = 30;
            button3.Text = "Yearly";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.Location = new Point(819, 296);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 29;
            button2.Text = "Monthly";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.Location = new Point(819, 251);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 28;
            button1.Text = "Weekly";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Text", 36F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(335, 46);
            label1.Name = "label1";
            label1.Size = new Size(129, 69);
            label1.TabIndex = 31;
            label1.Text = "Sale";
            // 
            // Statistic
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Info;
            ClientSize = new Size(932, 619);
            Controls.Add(label1);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(dataGridView1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Statistic";
            Text = "Statistic";
            Load += Statistic_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem stocksToolStripMenuItem;
        private DataGridView dataGridView1;
        private Button button3;
        private Button button2;
        private Button button1;
        private ToolStripMenuItem thongCuteToolStripMenuItem;
        private Label label1;
    }
}