﻿namespace HeThongSach
{
    partial class ExportSlip
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            label17 = new Label();
            label16 = new Label();
            label15 = new Label();
            id = new TextBox();
            SED = new TextBox();
            total = new TextBox();
            price = new TextBox();
            label14 = new Label();
            label13 = new Label();
            label12 = new Label();
            label11 = new Label();
            label10 = new Label();
            label9 = new Label();
            quantity = new TextBox();
            bookid = new TextBox();
            DOD = new TextBox();
            dname = new TextBox();
            add = new TextBox();
            phone = new TextBox();
            label8 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            agentid = new TextBox();
            button1 = new Button();
            button2 = new Button();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ActiveCaption;
            panel1.Controls.Add(label17);
            panel1.Controls.Add(label16);
            panel1.Controls.Add(label15);
            panel1.Controls.Add(id);
            panel1.Controls.Add(SED);
            panel1.Controls.Add(total);
            panel1.Controls.Add(price);
            panel1.Controls.Add(label14);
            panel1.Controls.Add(label13);
            panel1.Controls.Add(label12);
            panel1.Controls.Add(label11);
            panel1.Controls.Add(label10);
            panel1.Controls.Add(label9);
            panel1.Controls.Add(quantity);
            panel1.Controls.Add(bookid);
            panel1.Controls.Add(DOD);
            panel1.Controls.Add(dname);
            panel1.Controls.Add(add);
            panel1.Controls.Add(phone);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(agentid);
            panel1.Location = new Point(47, 37);
            panel1.Name = "panel1";
            panel1.Size = new Size(834, 605);
            panel1.TabIndex = 3;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(622, 398);
            label17.Name = "label17";
            label17.Size = new Size(109, 15);
            label17.TabIndex = 30;
            label17.Text = "Director's signature";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(342, 398);
            label16.Name = "label16";
            label16.Size = new Size(109, 15);
            label16.TabIndex = 29;
            label16.Text = "Delivery's signature";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(57, 398);
            label15.Name = "label15";
            label15.Size = new Size(128, 15);
            label15.TabIndex = 28;
            label15.Text = "Export Staff's signature";
            // 
            // id
            // 
            id.Location = new Point(622, 337);
            id.Name = "id";
            id.Size = new Size(122, 23);
            id.TabIndex = 27;
            // 
            // SED
            // 
            SED.Location = new Point(434, 337);
            SED.Name = "SED";
            SED.Size = new Size(128, 23);
            SED.TabIndex = 26;
            // 
            // total
            // 
            total.Location = new Point(544, 253);
            total.Name = "total";
            total.Size = new Size(129, 23);
            total.TabIndex = 25;
            // 
            // price
            // 
            price.Location = new Point(365, 253);
            price.Name = "price";
            price.Size = new Size(134, 23);
            price.TabIndex = 24;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(622, 319);
            label14.Name = "label14";
            label14.Size = new Size(40, 15);
            label14.TabIndex = 22;
            label14.Text = "Slip ID";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(434, 319);
            label13.Name = "label13";
            label13.Size = new Size(90, 15);
            label13.TabIndex = 21;
            label13.Text = "Slip Export Date";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(544, 235);
            label12.Name = "label12";
            label12.Size = new Size(32, 15);
            label12.TabIndex = 20;
            label12.Text = "Total";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(365, 235);
            label11.Name = "label11";
            label11.Size = new Size(83, 15);
            label11.TabIndex = 19;
            label11.Text = "Price per Book";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point);
            label10.Location = new Point(32, 328);
            label10.Name = "label10";
            label10.Size = new Size(308, 32);
            label10.TabIndex = 18;
            label10.Text = "Published by V4T Company";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(220, 235);
            label9.Name = "label9";
            label9.Size = new Size(53, 15);
            label9.TabIndex = 17;
            label9.Text = "Quantity";
            // 
            // quantity
            // 
            quantity.Location = new Point(220, 253);
            quantity.Name = "quantity";
            quantity.Size = new Size(100, 23);
            quantity.TabIndex = 16;
            // 
            // bookid
            // 
            bookid.Location = new Point(45, 253);
            bookid.Name = "bookid";
            bookid.Size = new Size(100, 23);
            bookid.TabIndex = 15;
            // 
            // DOD
            // 
            DOD.Location = new Point(270, 171);
            DOD.Name = "DOD";
            DOD.Size = new Size(135, 23);
            DOD.TabIndex = 13;
            // 
            // dname
            // 
            dname.Location = new Point(32, 171);
            dname.Name = "dname";
            dname.Size = new Size(190, 23);
            dname.TabIndex = 12;
            dname.TextChanged += textBox4_TextChanged;
            // 
            // add
            // 
            add.Location = new Point(544, 108);
            add.Name = "add";
            add.Size = new Size(277, 23);
            add.TabIndex = 11;
            // 
            // phone
            // 
            phone.Location = new Point(365, 108);
            phone.Name = "phone";
            phone.Size = new Size(148, 23);
            phone.TabIndex = 10;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(45, 235);
            label8.Name = "label8";
            label8.Size = new Size(48, 15);
            label8.TabIndex = 9;
            label8.Text = "Book ID";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(270, 153);
            label6.Name = "label6";
            label6.Size = new Size(89, 15);
            label6.TabIndex = 7;
            label6.Text = "Date of delivery";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(32, 153);
            label5.Name = "label5";
            label5.Size = new Size(84, 15);
            label5.TabIndex = 6;
            label5.Text = "Delivery Name";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(544, 90);
            label4.Name = "label4";
            label4.Size = new Size(49, 15);
            label4.TabIndex = 5;
            label4.Text = "Address";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(365, 90);
            label3.Name = "label3";
            label3.Size = new Size(86, 15);
            label3.TabIndex = 4;
            label3.Text = "Phone number";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(32, 90);
            label2.Name = "label2";
            label2.Size = new Size(69, 15);
            label2.TabIndex = 3;
            label2.Text = "Book Agent";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 36F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(299, 24);
            label1.Name = "label1";
            label1.Size = new Size(240, 55);
            label1.TabIndex = 2;
            label1.Text = "Export Slip";
            // 
            // agentid
            // 
            agentid.Location = new Point(32, 108);
            agentid.Name = "agentid";
            agentid.Size = new Size(304, 23);
            agentid.TabIndex = 1;
            // 
            // button1
            // 
            button1.Location = new Point(703, 662);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 5;
            button1.Text = "Delete";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(793, 662);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 6;
            button2.Text = "Print";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // ExportSlip
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Info;
            ClientSize = new Size(928, 732);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(panel1);
            Name = "ExportSlip";
            Text = "ExportSlip";
            Load += ExportSlip_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Label label17;
        private Label label16;
        private Label label15;
        private TextBox id;
        private TextBox SED;
        private TextBox total;
        private TextBox price;
        private Label label14;
        private Label label13;
        private Label label12;
        private Label label11;
        private Label label10;
        private Label label9;
        private TextBox quantity;
        private TextBox bookid;
        private TextBox DOD;
        private TextBox dname;
        private TextBox add;
        private TextBox phone;
        private Label label8;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox agentid;
        private Button button1;
        private Button button2;
    }
}